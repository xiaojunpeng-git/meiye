<?php
declare(strict_types=1);
/** 010已验收问卷增量发布执行器：不迁移表、不改权限、不连接007；入口最后切换，支持逐文件回滚。 */
if(PHP_SAPI!=='cli')exit(2);
set_exception_handler(static function(Throwable $e):void{fwrite(STDERR,get_class($e).': '.$e->getMessage());exit(1);});
$backup=$argv[1]??'';$phase=$argv[2]??'';
if(!preg_match('#^/www/backups/010/round12-mini-[a-f0-9]{12}-[0-9]{14}$#D',$backup)||!in_array($phase,['prepare','install','verify','rollback'],true))throw new RuntimeException('Explicit 010 release required');
$root='/www/wwwroot/010.cc3798.com';chdir($root);require 'vendor/autoload.php';(new think\App($root.'/'))->initialize();
set_exception_handler(static function(Throwable $e):void{fwrite(STDERR,get_class($e).': '.$e->getMessage());exit(1);});
use think\facade\Db;
if(Db::query('SELECT DATABASE() db')[0]['db']!=='mohe_010_app'||(int)config('database.connections.mysql.hostport')!==3307)throw new RuntimeException('Wrong database');
$m=json_decode(file_get_contents($backup.'/payload/manifest.json'),true,512,JSON_THROW_ON_ERROR);
if($m['site']!=='010'||$m['fingerprint']!=='94b2160db32285c58ae120c3e3a631d04a617ce73eff0cc0ab059cb775b1262a')throw new RuntimeException('Wrong accepted payload');
function miniHash(string $p):?string{return is_file($p)?hash_file('sha256',$p):null;}
function miniRecord(string $p,array $data):void{if(file_put_contents($p,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR))===false)throw new RuntimeException('Evidence write failed');chmod($p,0600);}
function miniCopy(string $from,string $to):void{if(!is_dir(dirname($to)))mkdir(dirname($to),0755,true);$tmp=$to.'.r12-mini';if(!copy($from,$tmp))throw new RuntimeException('Copy failed');chmod($tmp,is_file($to)?fileperms($to)&0777:0644);chown($tmp,is_file($to)?fileowner($to):'www');chgrp($tmp,is_file($to)?filegroup($to):'www');if(!rename($tmp,$to))throw new RuntimeException('Atomic replace failed');}
/** 仅保存表计数和角色指纹；不会把会员答案或实例密钥输出到本机。 */
function miniMeta():array{$tables=[];foreach(['task','questionnaire','target','popup','answer','reward_config','reward']as$t)$tables[$t]=(int)Db::name('member_survey_'.$t)->count();return ['tables'=>$tables,'roles_sha256'=>hash('sha256',json_encode(Db::name('system_role')->order('id')->select()->toArray()))];}
foreach($m['files']as$p=>$h){if(!preg_match('#^(app/|config/|public/)#',$p)||strpos($p,'..')!==false)throw new RuntimeException('Invalid payload path');if(miniHash($backup.'/payload/files/'.$p)!==$h)throw new RuntimeException('Payload hash mismatch');}
if($phase==='prepare'){
 foreach($m['guard']as$p=>$h)if(miniHash($root.'/'.$p)!==$h)throw new RuntimeException('Live baseline changed: '.$p);
 foreach($m['before']as$p=>$h)if($h!==null){$dest=$backup.'/before/'.$p;if(!is_dir(dirname($dest)))mkdir(dirname($dest),0700,true);if(!copy($root.'/'.$p,$dest)||miniHash($dest)!==$h)throw new RuntimeException('Backup failed');chmod($dest,0600);}
 miniRecord($backup.'/before-meta.json',miniMeta());echo json_encode(['result'=>'PREPARED','files'=>count($m['files']),'database'=>'mohe_010_app']);exit;
}
if($phase==='install'){
 foreach($m['guard']as$p=>$h)if(miniHash($root.'/'.$p)!==$h)throw new RuntimeException('Prepared baseline changed: '.$p);
 foreach($m['files']as$p=>$h)if(!in_array($p,['public/system.html','public/index.html'],true))miniCopy($backup.'/payload/files/'.$p,$root.'/'.$p);
 // 仅在010自己的现有配置中增加体验码环境，保持其余字节和全部微信凭据原样。
 $env=file_get_contents($root.'/.env');$nl=strpos($env,"\r\n")!==false?"\r\n":"\n";
 $section='/^(\[MEMBER_SURVEY\][^\r\n]*\r?\n)(.*?)(?=^\[|\z)/msi';
 if(preg_match($section,$env))$next=preg_replace_callback($section,static function(array $s)use($nl):string{$body=$s[2];$key='/^MINI_ENV_VERSION\s*=.*$/mi';$body=preg_match($key,$body)?preg_replace($key,'MINI_ENV_VERSION = trial',$body):rtrim($body,"\r\n").$nl.'MINI_ENV_VERSION = trial'.$nl;return $s[1].$body;},$env);
 else $next=$env.$nl.'[MEMBER_SURVEY]'.$nl.'MINI_ENV_VERSION = trial'.$nl;
 miniRecord($backup.'/env-after.json',['sha256'=>hash('sha256',$next)]);$temp=$root.'/.env.r12-mini';if(file_put_contents($temp,$next)===false)throw new RuntimeException('Config write failed');chmod($temp,fileperms($root.'/.env')&0777);chown($temp,fileowner($root.'/.env'));chgrp($temp,filegroup($root.'/.env'));if(!rename($temp,$root.'/.env'))throw new RuntimeException('Config replace failed');
 foreach(['public/system.html','public/index.html']as$p)if(isset($m['files'][$p]))miniCopy($backup.'/payload/files/'.$p,$root.'/'.$p);
 echo json_encode(['result'=>'INSTALLED','files'=>count($m['files']),'env_sha256'=>hash('sha256',$next)]);exit;
}
if($phase==='rollback'){
 $envAfter=is_file($backup.'/env-after.json')?json_decode(file_get_contents($backup.'/env-after.json'),true)['sha256']:null;
 if(!in_array(miniHash($root.'/.env'),[$m['before']['.env'],$envAfter],true))throw new RuntimeException('Concurrent environment change');
 foreach($m['files']as$p=>$h)if(!in_array(miniHash($root.'/'.$p),[$h,$m['before'][$p]],true))throw new RuntimeException('Concurrent file change: '.$p);
 foreach($m['before']as$p=>$h){if($h!==null)miniCopy($backup.'/before/'.$p,$root.'/'.$p);elseif(isset($m['files'][$p])&&miniHash($root.'/'.$p)===$m['files'][$p])unlink($root.'/'.$p);}
 echo json_encode(['result'=>'ROLLED_BACK','business_data_restored'=>false]);exit;
}
foreach($m['files']as$p=>$h)if(miniHash($root.'/'.$p)!==$h)throw new RuntimeException('Installed hash mismatch: '.$p);
foreach($m['preserve']as$p=>$h)if(miniHash($root.'/'.$p)!==$h)throw new RuntimeException('Preserved entry changed: '.$p);
if(config('member_survey.mini_env_version')!=='trial'||sys_config('routine_appId')!=='wxce4f61fc9c4eaaa6')throw new RuntimeException('Wrong mini program configuration');
$before=json_decode(file_get_contents($backup.'/before-meta.json'),true);$after=miniMeta();if($before!==$after)throw new RuntimeException('Unexpected business or role change during deployment');
$service=new app\services\user\MemberSurveyServices();$list=$service->listTasks(1,20);
// 现网微信SDK使用Swoole HTTP适配器；CLI探测也必须建立协程，不能把探测环境错误误判为业务故障。
$code=null;$failure=null;
\Swoole\Coroutine\run(static function()use(&$code,&$failure):void{try{$code=(new app\services\user\MemberSurveyMiniProgramCodeServices())->make(str_repeat('f',48));}catch(Throwable $error){$failure=$error;}});
if($failure)throw $failure;if(!$code)throw new RuntimeException('Missing QR verification result');
echo json_encode(['result'=>'PASS','database'=>'mohe_010_app','source_commit'=>$m['source_commit'],'files'=>count($m['files']),'existing_data_and_roles_unchanged'=>true,'task_count'=>$list['count'],'qr_appid'=>$code['app_id'],'qr_environment'=>$code['env_version'],'qr_kind'=>$code['kind'],'qr_mime'=>substr($code['image'],0,strpos($code['image'],';')),'only_010'=>true],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
